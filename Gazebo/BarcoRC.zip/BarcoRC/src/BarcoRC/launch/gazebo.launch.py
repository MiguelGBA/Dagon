import os

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():

    # ------------ Args ------------
    use_sim_time = LaunchConfiguration('use_sim_time')
    declare_use_sim_time_cmd = DeclareLaunchArgument(
        name='use_sim_time',
        default_value='true',
        description='Use Gazebo clock if true'
    )

    # ------------ Package paths ------------
    package_name = 'BarcoRC'
    pkg_share = get_package_share_directory(package_name)

    # ------------ URDF ------------
    urdf_file_name = 'BarcoRC.urdf'
    urdf_path = os.path.join(pkg_share, 'urdf', urdf_file_name)

    with open(urdf_path, 'r') as infp:
        robot_desc = infp.read()

    # Quitar declaración XML para que spawn_entity no pete
    robot_desc = robot_desc.replace('<?xml version="1.0" encoding="utf-8"?>', '')
    robot_desc = robot_desc.replace('<?xml version="1.0"?>', '')

    # ------------ Robot State Publisher ------------
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{
            'use_sim_time': use_sim_time,
            'robot_description': robot_desc
        }]
    )

    # ------------ Joint State Publisher (NO GUI) ------------
    # Solo para publicar /joint_states en sim
    joint_state_publisher_node = Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
        name='joint_state_publisher',
        output='screen',
        parameters=[{'use_sim_time': use_sim_time}]
    )

    # ------------ Gazebo classic ------------
    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('gazebo_ros'),
                'launch',
                'gazebo.launch.py'
            )
        ),
        launch_arguments={'verbose': 'true'}.items()
    )

    # ------------ Spawn entity ------------
    spawn_entity_node = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-topic', 'robot_description',
            '-entity', 'BarcoRC',
            '-x', '0.0',
            '-y', '0.0',
            '-z', '0.05',
            '-Y', '0.0'
        ],
        output='screen'
    )

    # Esperar a que Gazebo suba
    delayed_spawn = TimerAction(
        period=3.0,
        actions=[spawn_entity_node]
    )

    return LaunchDescription([
        declare_use_sim_time_cmd,
        gazebo_launch,
        robot_state_publisher_node,
        joint_state_publisher_node,
        delayed_spawn
    ])

